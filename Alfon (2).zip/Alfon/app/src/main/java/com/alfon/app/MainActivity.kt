package com.alfon.app

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.provider.ContactsContract
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.webkit.WebViewAssetLoader
import org.json.JSONObject

class MainActivity : ComponentActivity() {

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    // בחירת קובץ אקסל / CSV עבור "טעינת קובץ"
    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { res ->
        fileCallback?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res.resultCode, res.data))
        fileCallback = null
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val root = FrameLayout(this)
        root.setBackgroundColor(Color.parseColor("#1F2F55"))
        web = WebView(this)
        root.addView(web, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)

        // שומרים מקום לשורת הסטטוס ולכפתורי הניווט
        ViewCompat.setOnApplyWindowInsetsListener(root) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars() or WindowInsetsCompat.Type.ime())
            v.setPadding(bars.left, bars.top, bars.right, bars.bottom)
            WindowInsetsCompat.CONSUMED
        }

        // הקבצים של האלפון נטענים מתוך האפליקציה עצמה (עובד בלי אינטרנט)
        val loader = WebViewAssetLoader.Builder()
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = false
            allowContentAccess = true
            textZoom = 100
        }
        web.setBackgroundColor(Color.parseColor("#EEF1F6"))
        web.addJavascriptInterface(Bridge(), "AlfonApp")

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == "appassets.androidplatform.net") return false
                // טלפון → חייגן, וואטסאפ וקישורים אחרים → האפליקציה המתאימה
                val action = if (u.scheme == "tel") Intent.ACTION_DIAL else Intent.ACTION_VIEW
                try {
                    startActivity(Intent(action, u))
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "לא נמצאה אפליקציה מתאימה", Toast.LENGTH_SHORT).show()
                }
                return true
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onShowFileChooser(
                view: WebView,
                callback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = callback
                val intent = Intent(Intent.ACTION_GET_CONTENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "*/*"
                    putExtra(
                        Intent.EXTRA_MIME_TYPES, arrayOf(
                            "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                            "application/vnd.ms-excel",
                            "text/csv",
                            "text/comma-separated-values",
                            "application/octet-stream"
                        )
                    )
                }
                return try {
                    pickFile.launch(intent); true
                } catch (e: Exception) {
                    fileCallback = null; false
                }
            }
        }

        // כפתור "חזרה": קודם סוגר חלון פתוח, ורק אז יוצא מהאפליקציה
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                web.evaluateJavascript("window.appBack?window.appBack():false") { r ->
                    if (r != "true") finish()
                }
            }
        })

        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://appassets.androidplatform.net/assets/www/index.html")
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    // "הוסף לאנשי הקשר" – פותח את מסך איש קשר חדש של הטלפון, עם כל הפרטים
    inner class Bridge {
        @JavascriptInterface
        fun addContact(json: String) {
            runOnUiThread {
                try {
                    val o = JSONObject(json)
                    val i = Intent(ContactsContract.Intents.Insert.ACTION).apply {
                        type = ContactsContract.RawContacts.CONTENT_TYPE
                        putExtra(ContactsContract.Intents.Insert.NAME, o.optString("name"))
                        val phones = o.optJSONArray("phones")
                        val keys = listOf(
                            ContactsContract.Intents.Insert.PHONE to ContactsContract.Intents.Insert.PHONE_TYPE,
                            ContactsContract.Intents.Insert.SECONDARY_PHONE to ContactsContract.Intents.Insert.SECONDARY_PHONE_TYPE,
                            ContactsContract.Intents.Insert.TERTIARY_PHONE to ContactsContract.Intents.Insert.TERTIARY_PHONE_TYPE
                        )
                        if (phones != null) {
                            for (k in 0 until minOf(phones.length(), 3)) {
                                val p = phones.getJSONObject(k)
                                putExtra(keys[k].first, p.optString("n"))
                                putExtra(
                                    keys[k].second,
                                    if (p.optBoolean("mob")) ContactsContract.CommonDataKinds.Phone.TYPE_MOBILE
                                    else ContactsContract.CommonDataKinds.Phone.TYPE_HOME
                                )
                            }
                        }
                        val addr = o.optString("address")
                        if (addr.isNotEmpty()) putExtra(ContactsContract.Intents.Insert.POSTAL, addr)
                        val note = o.optString("note")
                        if (note.isNotEmpty()) putExtra(ContactsContract.Intents.Insert.NOTES, note)
                    }
                    startActivity(i)
                } catch (e: Exception) {
                    Toast.makeText(this@MainActivity, "לא ניתן לפתוח את אנשי הקשר", Toast.LENGTH_SHORT).show()
                }
            }
        }
    }
}
